package org.example.joker.exceptions;

public class BadQuestionAnswerException extends Exception {
}
