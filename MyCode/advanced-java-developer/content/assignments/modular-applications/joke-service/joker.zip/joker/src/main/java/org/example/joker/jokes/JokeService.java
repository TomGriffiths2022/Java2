package org.example.joker.jokes;

import org.example.joker.exceptions.InvalidOrExpiredTokenException;
import org.example.joker.tokens.TokenStore;

import java.util.Random;

public class JokeService {

    private TokenStore tokenStore;

    private String[] jokes = {
            "My wife told me to stop acting like a flamingo so I had to put my foot down.",
            "Today, my son asked 'Can I have a book mark?' and I laughed. 11 years old and he still doesn't know my name is Brian.",
            "Did you know the first French fries weren't actually cooked in France? They were cooked in Greece.",
            "If a child refuses to sleep during nap time, are they guilty of resisting a rest?",
            "The secret service doesn't shout 'Get down!' when the president is about to be attacked. Now they shout 'Donald, duck!'",
            "I'm reading a book about anti-gravity. It's impossible to put down!",
            "What is the least spoken language in the world? Sign language.",
            "Did you hear about the kidnapping at school? The teacher woke him up.",
            "What do you call a hippy's wife? Mississippi.",
            "What did the evil chicken lay? Devilled eggs."
    };

    public JokeService() {
        this.tokenStore = TokenStore.getInstance();
    }

    public String getJoke(String token) throws InvalidOrExpiredTokenException {
        if (tokenStore.isTokenValid(token)) {
            tokenStore.removeToken(token);
            return jokes[new Random().nextInt(jokes.length)];
        } else {
            throw new InvalidOrExpiredTokenException();
        }
    }
}
