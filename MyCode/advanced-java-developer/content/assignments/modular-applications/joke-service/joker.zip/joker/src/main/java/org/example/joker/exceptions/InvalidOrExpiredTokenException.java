package org.example.joker.exceptions;

public class InvalidOrExpiredTokenException extends Exception {
}
