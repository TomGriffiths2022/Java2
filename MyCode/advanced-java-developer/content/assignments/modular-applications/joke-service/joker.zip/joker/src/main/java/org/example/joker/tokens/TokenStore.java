package org.example.joker.tokens;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class TokenStore {

    private Map<String, LocalDateTime> tokens;

    private static TokenStore tokenStore;
    private static final int TOKEN_VALID_FOR_MINS = 10;

    private TokenStore() {
        tokens = new HashMap<>();
    }

    public static TokenStore getInstance() {
        if (tokenStore == null) {
             tokenStore = new TokenStore();
        }
        return tokenStore;
    }

    public void addToken(String token) {
        tokens.put(token, LocalDateTime.now());
    }

    public void removeToken(String token) {
        tokens.remove(token);
    }

    public boolean isTokenValid(String token) {
        if (tokens.containsKey(token)) {
            if (tokens.get(token).plusMinutes(TOKEN_VALID_FOR_MINS).isAfter(LocalDateTime.now())) {
                return true;
            } else {
                tokens.remove(token);
                return false;
            }
        } else {
            return false;
        }
    }
}
