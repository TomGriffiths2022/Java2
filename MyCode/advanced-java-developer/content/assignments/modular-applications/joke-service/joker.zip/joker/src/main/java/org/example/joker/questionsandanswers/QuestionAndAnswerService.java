package org.example.joker.questionsandanswers;

import org.example.joker.exceptions.BadQuestionAnswerException;
import org.example.joker.tokens.TokenGenerator;
import org.example.joker.tokens.TokenStore;

import java.util.Map;
import java.util.Random;

public class QuestionAndAnswerService {

    private TokenGenerator tokenGenerator;
    private TokenStore tokenStore;

    private Map<String, String> questionsAndAnswers = Map.of(
            "In what year did WW1 begin?", "1914",
            "In what year was Napoleon Bonaparte defeated by the 7th coalition at the Battle of Waterloo?", "1815",
            "Which George was King of England at the outbreak of the WW2?", "6",
            "The Hundred Years War was fought between England and which other European country?", "France",
            "The Spanish Armada failed in its attempt to invade England in what year?", "1588",
            "The first fleet to Australia arrived at Botany Bay in what year?", "1788",
            "Which English monarch was executed in 1649?", "Charles I",
            "The battle of which Russian city is said to have been the turning point of WW2?", "Stalingrad",
            "In what year was Italy formally unified?", "1861",
            "The assassination of Archduke Franz Ferdinand sparked WW1. Of which empire was he heir?", "Austro-Hungarian"
    );

    public QuestionAndAnswerService() {
        this.tokenGenerator = new TokenGenerator();
        this.tokenStore = TokenStore.getInstance();
    }

    public String getQuestion() {
        return questionsAndAnswers.keySet().toArray(new String[]{})[new Random().nextInt(questionsAndAnswers.size())];
    }

    public String getToken(String question, String answer) throws BadQuestionAnswerException {
        if (questionsAndAnswers.get(question).equalsIgnoreCase(answer)) {
            var token = tokenGenerator.generateToken();
            tokenStore.addToken(token);
            return token;
        } else {
            throw new BadQuestionAnswerException();
        }
    }
}
