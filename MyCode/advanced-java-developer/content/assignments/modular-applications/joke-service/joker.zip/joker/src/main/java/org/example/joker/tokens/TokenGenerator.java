package org.example.joker.tokens;

import java.nio.charset.StandardCharsets;
import java.util.Random;

public class TokenGenerator {

    public String generateToken() {
        var byteArray = new byte[7];
        new Random().nextBytes(byteArray);
        return new String(byteArray, StandardCharsets.UTF_8);
    }
}
