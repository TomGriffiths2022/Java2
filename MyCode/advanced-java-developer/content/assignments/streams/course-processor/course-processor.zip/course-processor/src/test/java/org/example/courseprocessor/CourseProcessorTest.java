package org.example.courseprocessor;

import org.example.courseprocessor.models.Course;
import org.example.courseprocessor.models.Person;
import org.junit.jupiter.api.BeforeEach;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import static java.time.LocalDate.of;

public class CourseProcessorTest {

    private List<Course> courses;

    @BeforeEach
    public void setUp() throws IOException {
        Person al = new Person("Alan", "Lavender", "alanl@stayahead.com", "207-600-6116");
        Person bs = new Person("Brian", "Short", "brians@stayahead.com", "207-600-6116");
        Person kf = new Person("Kevin", "Fitzsimons", "kevinf@stayahead.com", "207-600-6116");
        Person mb = new Person("Musie", "Beyene", "musieb@stayahead.com", "207-600-6116");
        Person sb = new Person("Stuart", "Bailey", "stuartb@stayahead.com", "207-600-6116");
        BufferedReader reader = new BufferedReader(new FileReader("delegates.csv"));
        courses = List.of(
                new Course("Java 1", 5, of(2021, 2, 1), al).withDelegates(reader, 10),
                new Course("JEE", 5, of(2021, 2, 15), bs).withDelegates(reader, 3),
                new Course("Python 1", 4, of(2021, 2, 16), kf).withDelegates(reader, 8),
                new Course("Python 2", 3, of(2021, 3, 10), mb).withDelegates(reader, 4),
                new Course("Spring", 4, of(2021, 3, 23), sb).withDelegates(reader, 6),
                new Course("HTML", 3, of(2021, 4, 5), al).withDelegates(reader, 1),
                new Course("Python 1", 4, of(2021, 4, 13), kf).withDelegates(reader, 12),
                new Course("React", 4, of(2021, 4, 27), sb).withDelegates(reader, 3),
                new Course("React", 4, of(2021, 5, 11), sb).withDelegates(reader, 3),
                new Course("Java 1", 5, of(2021, 2, 7), al).withDelegates(reader, 10)
        );
        reader.close();
    }
}
