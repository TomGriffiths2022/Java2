package org.example.courseprocessor;

public class CourseProcessor {
}
