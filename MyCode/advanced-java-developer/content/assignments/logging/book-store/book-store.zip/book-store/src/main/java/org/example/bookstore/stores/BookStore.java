package org.example.bookstore.stores;

import org.example.bookstore.models.Book;

import java.util.LinkedList;
import java.util.List;

public class BookStore {

    private List<Book> books;

    public BookStore() {
        books = new LinkedList<>();
    }

    public void addBook(Book book) {
        if (!bookIsAlreadyInTheStore(book.getTitle())) {
            books.add(book);
        }
    }

    private boolean bookIsAlreadyInTheStore(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return true;
            }
        }
        return false;
    }

    public int numBooks() {
        return books.size();
    }

    public List<Book> findByPartialTitle(String partialTitle) {
        List<Book> matchingBooks = new LinkedList<>();
        for (Book book : books) {
            if (book.getTitle().toLowerCase().contains(partialTitle.toLowerCase())) {
                matchingBooks.add(book);
            }
        }
        return matchingBooks;
    }

    public List<Book> findByAuthor(String author) {
        List<Book> matchingBooks = new LinkedList<>();
        for (Book book : books) {
            if (book.getAuthor().equalsIgnoreCase(author)) {
                matchingBooks.add(book);
            }
        }
        return matchingBooks;
    }
}
