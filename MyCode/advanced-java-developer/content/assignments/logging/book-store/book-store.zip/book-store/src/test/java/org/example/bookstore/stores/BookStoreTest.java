package org.example.bookstore.stores;

import org.example.bookstore.models.Book;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import org.junit.Before;
import org.junit.Test;

public class BookStoreTest {

    private BookStore bookStore;
    private Book animalFarm;

    @Before
    public void setUp() {
        bookStore = new BookStore();
        animalFarm = new Book("Animal Farm", "George Orwell");
    }

    @Test
    public void testAddNewBook() {
        bookStore.addBook(animalFarm);
        assertThat(bookStore.numBooks(), is(1));
    }

    @Test
    public void testAddDuplicateBook() {
        bookStore.addBook(animalFarm);
        bookStore.addBook(animalFarm);
        assertThat(bookStore.numBooks(), is(1));
    }

    @Test
    public void testFindByPartialTitleWhenThereAreMatchingTitles() {
        bookStore.addBook(animalFarm);
        assertThat(bookStore.findByPartialTitle("far"), hasItem(animalFarm));
    }

    @Test
    public void testFindByPartialTitleWhenThereAreNoMatchingTitles() {
        assertThat(bookStore.findByPartialTitle("far").size(), is(0));
    }
}
